# Nester By Li Xin

This a simple printer of nested lists. You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.